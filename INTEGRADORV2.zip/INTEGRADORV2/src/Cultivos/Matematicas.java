/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cultivos;

import java.util.LinkedList;
import java.util.Vector;

/**
 *
 * @author quiroz
 */
public class Matematicas {

    public float[] Promedios(LinkedList lista) {
        float[] vector = new float[6];
        int iteraciones = 0;
        for (int i = 0; i < lista.size(); i += 6) {
            iteraciones++;
            for (int j = 0; j < 6; j++) {
                vector[j] += Float.parseFloat(String.valueOf(lista.get(j + i)));
            }
        }
        for (int i = 0; i < 6; i++) {
            vector[i] /= iteraciones;
        }
        return vector;
    }

    public LinkedList Promedios(LinkedList maximos, LinkedList minimos) {
        LinkedList lista = new LinkedList();
        int bandera = 0;
        for (int i = 0; i < maximos.size(); i++) {
            if (i == bandera) {
                bandera += 7;
                lista.add(String.valueOf(minimos.get(i)));
                continue;
            }
            lista.add(String.valueOf((Float.parseFloat(String.valueOf(maximos.get(i)))
                    + Float.parseFloat(String.valueOf(minimos.get(i)))) / 2));
        }
        return lista;
    }

    public LinkedList Comparar(float[] promedio, LinkedList optimo) {
        LinkedList lista = new LinkedList();
        float auxiliar = 0;
        for (int i = 1; i < optimo.size(); i += 7) {
            lista.add(optimo.get(i - 1));
            for (int j = 0; j < 6; j++) {
                auxiliar = Float.parseFloat(String.valueOf(optimo.get(j + i)));
                if (auxiliar >= promedio[j]) {
                    lista.add(String.valueOf(auxiliar - promedio[j]));
                }
                if (auxiliar < promedio[j]) {
                    lista.add(String.valueOf(promedio[j] - auxiliar));
                }
            }
        }
        return lista;
    }

    public LinkedList Ponderacion(LinkedList puntaje) {
        LinkedList lista = new LinkedList();
        float maximo = 0;
        float suma = 0;
        int parametro = 0;
        for (int i = 1; i < puntaje.size(); i += 7) {
            lista.add(puntaje.get(i - 1));
            suma = 0;
            maximo = 0;
            parametro = 0;
            for (int j = 0; j < 6; j++) {
                suma += Float.parseFloat(String.valueOf(puntaje.get(j + i)));
                if (maximo < Float.parseFloat(String.valueOf(puntaje.get(j + i)))) {
                    maximo = Float.parseFloat(String.valueOf(puntaje.get(j + i)));
                    parametro = j;
                }
            }
            lista.add(suma);
            lista.add(maximo);
            lista.add(parametro);
        }
        return lista;
    }

    public LinkedList Ordenamiento(LinkedList ListaPonderada) {
        LinkedList lista = new LinkedList();
        LinkedList listaAux = new LinkedList();
        float auxiliari = 0;
        float auxiliarj = 0;
        float intercambio = 0;
        for (int i = 1; i < ListaPonderada.size(); i += 4) {
            for (int j = i + 4; j < ListaPonderada.size(); j += 4) {
                auxiliari = Float.parseFloat(String.valueOf(ListaPonderada.get(i)));
                auxiliarj = Float.parseFloat(String.valueOf(ListaPonderada.get(j)));
                if (auxiliari > auxiliarj) {
                    lista.add(0, ListaPonderada.get(i - 1));
                    lista.add(1, ListaPonderada.get(i));
                    lista.add(2, ListaPonderada.get(i + 1));
                    lista.add(3, ListaPonderada.get(i + 2));
                    ListaPonderada.set(i - 1, ListaPonderada.get(j - 1));
                    ListaPonderada.set(i, ListaPonderada.get(j));
                    ListaPonderada.set(i + 1, ListaPonderada.get(j + 1));
                    ListaPonderada.set(i + 2, ListaPonderada.get(j + 2));
                    ListaPonderada.set(j - 1, lista.get(0));
                    ListaPonderada.set(j, lista.get(1));
                    ListaPonderada.set(j + 1, lista.get(2));
                    ListaPonderada.set(j + 2, lista.get(3));
                }
            }
        }
        lista.removeAll(lista);
        for (int i = 1; i < ListaPonderada.size(); i += 4) {
            lista.add(ListaPonderada.get(i - 1));
            lista.add(ListaPonderada.get(i));
            lista.add(ListaPonderada.get(i + 1));
            lista.add(ListaPonderada.get(i + 2));
        }
        return lista;
    }
}
