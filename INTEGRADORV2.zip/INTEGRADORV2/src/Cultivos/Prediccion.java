/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cultivos;

import OperacionesSQL.Consultas;
import OperacionesSQL.Plantas;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Prediccion {

    public LinkedList CultivosAptos(String FechaInicial, String FechaFinal) {
        LinkedList lista = new LinkedList();
        LinkedList listaMax = new LinkedList();
        LinkedList ValoresOptimos = new LinkedList();
        float[] LecturaPromedio = new float[6];
        String Query = "SELECT * FROM Medida WHERE Fecha BETWEEN '" + FechaInicial
                + "' AND '" + FechaFinal + "'";
        lista = ParametrosLecturas();
        Consultas consulta = new Consultas();
        lista = consulta.ConsultaGenerica(Query, lista);
        Matematicas matematicas = new Matematicas();
        LecturaPromedio = matematicas.Promedios(lista);
        Plantas planta = new Plantas();
        lista = planta.ParametrosDePlantas("Min");
        listaMax = planta.ParametrosDePlantas("Max");
        Query = "SELECT * FROM Planta";
        lista = planta.ConsultaPlantas(Query, lista);
        listaMax = planta.ConsultaPlantas(Query, listaMax);
        ValoresOptimos = matematicas.Promedios(lista, listaMax);
        lista = matematicas.Comparar(LecturaPromedio, ValoresOptimos);
        lista = matematicas.Ponderacion(lista);
        lista = matematicas.Ordenamiento(lista);
        lista = RelacionarParametros(lista);
        return lista;
    }

    public LinkedList ParametrosLecturas() {
        LinkedList lista = new LinkedList();
        lista.add("T_a");
        lista.add("T_s");
        lista.add("H_a");
        lista.add("H_s");
        lista.add("Luxes");
        lista.add("Co2");
        return lista;
    }

    public LinkedList RelacionarParametros(LinkedList lista) {
        for (int i = 3; i < lista.size(); i += 4) {
            String aux = lista.get(i).toString();
            if (aux.equals("0")) {
                lista.set(i, "Humedad de suelo");
            }
            if (aux.equals("1")) {
                lista.set(i, "Humedad ambiente");
            }
            if (aux.equals("2")) {
                lista.set(i, "Temperatura de suelo");
            }
            if (aux.equals("3")) {
                lista.set(i, "Temperatura ambiente");
            }
            if (aux.equals("4")) {
                lista.set(i, "Luxes");
            }
            if (aux.equals("5")) {
                lista.set(i, "Co2");
            }
        }
        return lista;
    }

    public static void main(String[] ar) {
        Prediccion pred = new Prediccion();
        pred.CultivosAptos("2017/02/28", "2017/10/28");
    }
}
