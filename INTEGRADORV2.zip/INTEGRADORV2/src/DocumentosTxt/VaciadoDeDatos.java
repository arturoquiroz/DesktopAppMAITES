/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DocumentosTxt;

import OperacionesSQL.Lecturas;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import javax.swing.JOptionPane;

/**
 *
 * @author quiroz
 */
public class VaciadoDeDatos {

    public void VaciarDatos(String ruta) {
        LinkedList lista = new LinkedList();
        System.out.println("ruta = " + ruta);
        try {
            BufferedReader bf = new BufferedReader(new FileReader(ruta));
            String linea = bf.readLine();
            System.out.println(linea);
            if (linea.equals("--MAITES--")) {
                while ((linea = bf.readLine()) != null) {
                    lista.add(linea);
                }
                bf.close();
            } else {
                JOptionPane.showMessageDialog(null, "Documento erroneo o vacio,"
                        + "no se puede realizar la extraccion de datos");
            }
            Lecturas lecturas = new Lecturas();
            if (lecturas.Agregarlecturas(lista)) {
                JOptionPane.showMessageDialog(null, "Vaciado de datos exitoso");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo completar el vaciado");
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(ruta));
            bw.write("--MAITES--");
            bw.close();
        } catch (Exception e) {
            System.out.println("Error en el metodo de vaciado de datos: " + e);
        }
    }
}
