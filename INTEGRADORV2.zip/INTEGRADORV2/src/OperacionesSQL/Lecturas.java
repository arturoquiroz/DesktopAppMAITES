/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesSQL;

import java.sql.Connection;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Lecturas {

    public boolean Agregarlecturas(LinkedList lista) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            for (int i = 0; i < lista.size(); i += 8) {
                Statement stmt = conexion.createStatement();
                stmt.executeUpdate("INSERT INTO Medida (Fecha, Hora, T_a, H_a, T_s, "
                        + "H_s, Luxes, Co2) VALUES ('" + lista.get(i) + "', '" + lista.get(i + 1)
                        + "', " + lista.get(i + 2) + ", " + lista.get(i + 3) + ", " + lista.get(i + 4)
                        + ", " + lista.get(i + 5) + ", " + lista.get(i + 6) + ", " + lista.get(i + 7) + ")");
            }
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al agregar lecturas: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }

    public boolean Editarlecturas(LinkedList lista, int folio) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        String a  = "UPDATE Medida SET Hora='" + lista.get(0) + "', "
                        + "T_a=" + lista.get(1)
                        + ", H_a=" + lista.get(2) + ", T_s=" + lista.get(3)
                        + ", H_s=" + lista.get(4) + ", Luxes=" + lista.get(5)
                        + ", Co2=" + lista.get(6) + " WHERE Folio=" + folio;
        System.out.println(a);
        try {           
                Statement stmt = conexion.createStatement();
                stmt.executeUpdate("UPDATE Medida SET Hora='" + lista.get(0) + "', "
                        + "T_a=" + lista.get(1)
                        + ", H_a=" + lista.get(2) + ", T_s=" + lista.get(3)
                        + ", H_s=" + lista.get(4) + ", Luxes=" + lista.get(5)
                        + ", Co2=" + lista.get(6) + " WHERE idMedida =" + folio);
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al editar lecturas: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }

    public boolean Eliminarlecturas(int folio) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate("DELETE FROM Medida WHERE idMedida=" + folio);
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al eliminar lecturas: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }
}
