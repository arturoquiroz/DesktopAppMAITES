/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesSQL;

import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author quiroz
 */
public class Usuarios {

    public boolean Agregarusuario(String nombre, String contra, String tipo) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate("INSERT INTO usuarios (nombre, contra, tipo) VALUES "
                    + "('" + nombre + "', '" + contra + "', " + tipo + ")");
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al agregar usuario: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }

    public boolean Eliminarusuario(String idusuario) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate("DELETE FROM usuarios WHERE idusuario =" + idusuario);
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al eliminar usuario: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }

    public boolean Editarusuario(String nombre, String contra, String tipo, String idusuario) {
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        System.out.println("UPDATE usuarios SET contra='" + contra
                    + "', tipo = " + tipo + ", nombre='" + nombre + "' "
                    + "WHERE idusuario = "+ idusuario);
        try {
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate("UPDATE usuarios SET contra='" + contra
                    + "', tipo = " + tipo + ", nombre = '" + nombre + "' "
                    + "WHERE idusuario = "+ idusuario);
            conexion.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error al editar el usuario: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            return false;
        }
    }
}
