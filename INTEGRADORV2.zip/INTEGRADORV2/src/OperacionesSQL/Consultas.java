/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesSQL;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Consultas {

    public LinkedList ConsultarLecturas(String filtro, String parametro) {
        LinkedList lista = new LinkedList();
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            System.out.println("SELECT * FROM Medida WHERE " + filtro
                    + " = " + parametro);
            ResultSet rs = stmt.executeQuery("SELECT * FROM Medida WHERE " + filtro
                    + " = " + parametro);
            while (rs.next()) {
                lista.add(rs.getString("Fecha"));
                lista.add(rs.getString("Hora"));
                lista.add(rs.getString("T_a"));
                lista.add(rs.getString("H_a"));
                lista.add(rs.getString("T_s"));
                lista.add(rs.getString("H_s"));
                lista.add(rs.getString("Luxes"));
                lista.add(rs.getString("Co2"));
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error consultando Lecturas: " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
        }
        return lista;
    }

    public LinkedList ConsultaUsuario(String nombre) {
        LinkedList lista = new LinkedList();
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * from usuarios Where nombre ="
                    + " '" + nombre + "'");
            while (rs.next()) {
                lista.add(rs.getString("idusuario"));
                lista.add(rs.getString("nombre"));
                lista.add(rs.getString("contra"));
                lista.add(rs.getString("tipo"));
            }
        } catch (Exception e) {

        }
        return lista;
    }

    public LinkedList ConsultaParametros(String id) {
        LinkedList lista = null;
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * from parametros WHERE"
                    + " id = " + id);
            while (rs.next()) {
                lista.add(rs.getString("Tamax"));
                lista.add(rs.getString("Tamin"));
                lista.add(rs.getString("Tsmax"));
                lista.add(rs.getString("Tsmin"));
                lista.add(rs.getString("Hamax"));
                lista.add(rs.getString("Hamin"));
                lista.add(rs.getString("Hsmax"));
                lista.add(rs.getString("Hsmin"));
                lista.add(rs.getString("Luxmax"));
                lista.add(rs.getString("Luxmin"));
                lista.add(rs.getString("Co2max"));
                lista.add(rs.getString("Co2min"));
            }
            conexion.close();
        } catch (Exception e) {
            try {
                conexion.close();
            } catch (Exception ex) {
            }
            System.out.println("Error al consultar parametros: " + e);
        }
        return lista;
    }

    public LinkedList ConsultaGenerica(String Query, String Parametro) {
        LinkedList lista = new LinkedList();
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(Query);
            while (rs.next()) {
                lista.add(rs.getString(Parametro));
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error consultando de forma generica: (metodo 1)" + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
        }
        return lista;
    }

    public LinkedList ConsultaGenerica(String Query, LinkedList parametros) {
        LinkedList lista = new LinkedList();
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(Query);
            while (rs.next()) {
                for (int i = 0; i < parametros.size(); i++) {
                    lista.add(rs.getString(String.valueOf(parametros.get(i))));
                }
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error consultando de forma generica (metodo 2): " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
        }
        return lista;
    }
}
