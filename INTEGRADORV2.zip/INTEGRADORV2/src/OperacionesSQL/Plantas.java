/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OperacionesSQL;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Plantas {

    public LinkedList ConsultaPlantas(String Query, LinkedList parametros) {
        LinkedList lista = new LinkedList();
        Conexion con = new Conexion();
        Connection conexion = con.conectar();
        try {
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(Query);
            while (rs.next()) {
                for (int i = 0; i < parametros.size(); i++) {
                    lista.add(rs.getString(String.valueOf(parametros.get(i))));
                }
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error consultando plantas : " + e);
            try {
                conexion.close();
            } catch (Exception ex) {
            }
        }
        return lista;
    }

    public LinkedList ParametrosDePlantas() {
        LinkedList lista = new LinkedList();
        lista.add("HumedadS_Min");
        lista.add("HumedadS_Max");
        lista.add("HumedadA_Min");
        lista.add("HumedadA_Max");
        lista.add("TemperaturaS_Min");
        lista.add("TemperaturaS_Max");
        lista.add("TemperaturaA_Min");
        lista.add("TemperaturaA_Max");
        lista.add("Luxes_Min");
        lista.add("Luxes_Max");
        lista.add("Co2_Min");
        lista.add("Co2_Max");
        lista.add("Nombre");
        return lista;
    }

    public LinkedList ParametrosDePlantas(String MaxOMin) {
        LinkedList lista = new LinkedList();
        if (MaxOMin.equals("Max")) {
            lista.add("Nombre");
            lista.add("HumedadS_Max");
            lista.add("HumedadA_Max");
            lista.add("TemperaturaS_Max");
            lista.add("TemperaturaA_Max");
            lista.add("Luxes_Max");
            lista.add("Co2_Max");
            return lista;
        }
        if (MaxOMin.equals("Min")) {
            lista.add("Nombre");
            lista.add("HumedadS_Min");
            lista.add("HumedadA_Min");
            lista.add("TemperaturaS_Min");
            lista.add("TemperaturaA_Min");
            lista.add("Luxes_Min");
            lista.add("Co2_Min");
            return lista;
        }
        return lista;
    }
}
