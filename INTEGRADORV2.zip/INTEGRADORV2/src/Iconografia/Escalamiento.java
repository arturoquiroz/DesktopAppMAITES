/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Iconografia;

import javax.swing.ImageIcon;

/**
 *
 * @author quiroz
 */
public class Escalamiento {

    public ImageIcon Icono(String ruta, int ancho, int alto) {
        java.net.URL imgUrl = getClass().getResource(ruta);
        ImageIcon tmpIconAux = new ImageIcon(imgUrl);
        ImageIcon Icon = new ImageIcon(tmpIconAux.getImage().
                getScaledInstance(ancho, alto, java.awt.Image.SCALE_DEFAULT));
        return Icon;
    }
}
