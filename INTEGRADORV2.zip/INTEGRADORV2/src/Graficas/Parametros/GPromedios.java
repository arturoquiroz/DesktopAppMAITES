/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficas.Parametros;

import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class GPromedios {

    public float promediar(LinkedList lista) {
        float promedio = 0;
        short contador = 0;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i) != null) {
                promedio += Float.parseFloat(String.valueOf(lista.get(i)));
            } else {
                promedio += 0;
            }
            contador++;
        }
        if(promedio>0){
        promedio /= contador;    
        }else{
         promedio = 0;   
        }
        return promedio;
    }

}
