/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficas.Parametros;

/**
 *
 * @author quiroz
 */
public class DiasDelMes {
    public int Dias(int mes){
        if(mes == 1)
        return 31;
        if(mes == 2)
        return 28;
        if(mes == 3)
        return 31;
        if(mes == 4)
        return 30;
        if(mes == 5)
        return 31;
        if(mes == 6)
        return 30;
        if(mes == 7)
        return 31;
        if(mes == 8)
        return 31;
        if(mes == 9)
        return 30;
        if(mes == 10)
        return 31;
        if(mes == 11)
        return 30;
        if(mes == 12)
        return 31;
        return 0;
    }
}

