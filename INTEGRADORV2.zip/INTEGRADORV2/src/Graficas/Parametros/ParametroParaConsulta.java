/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficas.Parametros;

/**
 *
 * @author quiroz
 */
public class ParametroParaConsulta {

    public String Parametro(String cadena) {
        if (cadena.equals("temperatura ambiente")) {
            return "T_a";
        }
        if (cadena.equals("humedad ambiente")) {
            return "H_a";
        }
        if (cadena.equals("temperatura del suelo")) {
            return "T_s";
        }
        if (cadena.equals("humedad del suelo")) {
            return "H_s";
        }
        if (cadena.equals("luxes")) {
            return "Luxes";
        }
        if (cadena.equals("co2")) {
            return "Co2";
        }
        return "";
    }
}
