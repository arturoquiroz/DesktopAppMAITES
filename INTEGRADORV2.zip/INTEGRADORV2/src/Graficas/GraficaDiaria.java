/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graficas;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.LinkedList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;

/**
 *
 * @author quiroz
 */
public class GraficaDiaria extends ApplicationFrame {

    public GraficaDiaria(String applicationTitle, String chartTitle, LinkedList lista) {
        super(applicationTitle);
        JFreeChart lineChart = ChartFactory.createLineChart(
                chartTitle, "Numero de lectura", "Lecturas", createDataset(lista),
                PlotOrientation.VERTICAL,
                true, true, false);
        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        setContentPane(chartPanel);
        try {
            OutputStream out = new FileOutputStream("/home/quiroz/Documentos/Grafica Diaria.png");
            ChartUtilities.writeChartAsPNG(out, lineChart, 1250, 700);
        } catch (IOException ex) {
            System.out.println("Error generando el archivo de la grafica:  " + ex);
        }
    }

    private DefaultCategoryDataset createDataset(LinkedList lista) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < lista.size(); i++) {
            dataset.addValue(Float.parseFloat(String.valueOf(lista.get(i))), "Comportamiento", (i + 1));
        }
        return dataset;
    }
}
