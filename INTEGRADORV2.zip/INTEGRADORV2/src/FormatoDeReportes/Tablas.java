/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormatoDeReportes;

import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Tablas {
    public PdfPTable NuevaTabla(String [] titulo, LinkedList contenido, int columnas){
        PdfPTable table = new PdfPTable(columnas);
        PdfPCell columnHeader;
        for (int i = 0; i < columnas; i++) {
            columnHeader = new PdfPCell(new Phrase(titulo[i]));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
        }
        for (int i = 0; i < contenido.size(); i++){
                 table.addCell(contenido.get(i).toString());
            }
        return table;
    }
     public PdfPTable NuevaTabla(String [] titulo,float [] contenido, int columnas){
        PdfPTable table = new PdfPTable(columnas);
        PdfPCell columnHeader;
        for (int i = 0; i < columnas; i++) {
            columnHeader = new PdfPCell(new Phrase(titulo[i]));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
        }
        for (int i = 0; i < contenido.length; i++){
                 table.addCell(String.valueOf(contenido[i]));
            }
        return table;
    }
    
}
