/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes.parametros;

import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Promedios {
    public float[] ObtenerPromedios(LinkedList lista) {
        float[] vector = new float[6];
        int iteraciones=0;
        for (int i = 2; i < lista.size(); i += 8) {
            iteraciones ++;
            for (int j = 0; j < 6; j++) {
                    vector [j] += Float.parseFloat(String.valueOf(lista.get(j+i)));
            }
        }
        for (int i = 0; i < 6; i ++){
            vector [i] /= iteraciones;
        }
        return vector;
    }
}
