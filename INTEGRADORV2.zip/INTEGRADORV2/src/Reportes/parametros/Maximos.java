/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes.parametros;

import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Maximos {

    public float[] ObtenerMaximos(LinkedList lista) {
        float[] vector = new float[6];
        float auxiliar;
        int iteraciones = 0;
        for (int i = 0; i < vector.length; i++) {
            vector[i] = -1000;
        }
        for (int i = 2; i < lista.size(); i += 8) {
            iteraciones++;
            for (int j = 0; j < 6; j++) {
                auxiliar = Float.parseFloat(lista.get(j + i).toString());
                if (vector[j] <= auxiliar) {
                    vector[j] = auxiliar;
                }
            }
        }
        return vector;
    }
}
