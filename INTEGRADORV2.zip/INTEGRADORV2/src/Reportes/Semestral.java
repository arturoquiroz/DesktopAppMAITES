/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

import FormatoDeReportes.Tablas;
import Reportes.parametros.Maximos;
import Reportes.parametros.Minimos;
import Reportes.parametros.Promedios;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.util.LinkedList;

/**
 *
 * @author quiroz
 */
public class Semestral {

    public boolean Reporte(LinkedList lista) {
        Maximos obj1 = new Maximos();
        Minimos obj2 = new Minimos();
        Promedios obj3 = new Promedios();
        Tablas tablas = new Tablas();
        float[] vectordemaximos = obj1.ObtenerMaximos(lista);
        float[] vectordeminimos = obj2.ObtenerMinimos(lista);
        float[] vectordepromedios = obj3.ObtenerPromedios(lista);
        String[] vector = {"Fecha", "Hora", "H suelo", "H aire", "T suelo", "T aire", "Luxes", " Co2 "};
        String[] vector2 = {"H suelo", "H aire", "T suelo", "T aire", "Luxes", " Co2 "};
        Font fuente = new Font(Font.FontFamily.TIMES_ROMAN);
        fuente.setColor(BaseColor.RED);
        PdfPTable table = tablas.NuevaTabla(vector, lista, 8);
        try {
            FileOutputStream archivo = new FileOutputStream("/home/quiroz/Documentos/REPORTE SEMESTRAL.pdf");
            Document doc = new Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();
            Image imagen = Image.getInstance("logo.png");
            imagen.setAlignment(Element.ALIGN_RIGHT);
            doc.add(imagen);
            Chunk salto_linea = new Chunk("\n");
            doc.add(new Paragraph("REPORTE "));
            doc.add(salto_linea);
            doc.add(new Paragraph("VALORES GENERALES DE ESTE INTERVALO", fuente));
            doc.add(salto_linea);
            doc.add(table);
            table.flushContent();
            doc.add(salto_linea);
            doc.add(new Paragraph("VALORES MAXIMOS DE ESTE INTERVALO", fuente));
            table = tablas.NuevaTabla(vector2, vectordemaximos, 6);
            doc.add(salto_linea);
            doc.add(table);
            table.flushContent();
            doc.add(salto_linea);
            doc.add(new Paragraph("VALORES MINIMOS DE ESTE INTERVALO", fuente));
            table = tablas.NuevaTabla(vector2, vectordeminimos, 6);
            doc.add(salto_linea);
            doc.add(table);
            table.flushContent();
            doc.add(salto_linea);
            doc.add(new Paragraph("VALORES PROMEDIO DE ESTE INTERVALO", fuente));
            table = tablas.NuevaTabla(vector2, vectordepromedios, 6);
            doc.add(salto_linea);
            doc.add(table);
            doc.close();

        } catch (Exception e) {
            System.out.println("Excepcion generando reporte: " + e);
        }

        return true;
    }
}
