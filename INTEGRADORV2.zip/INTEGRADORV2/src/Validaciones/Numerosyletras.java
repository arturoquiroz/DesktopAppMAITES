/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validaciones;

/**
 *
 * @author quiroz
 */
public class Numerosyletras {
    public boolean Esnumero(String cadena){
        try{
            double numero = Double.parseDouble(cadena);
            return true;
        }catch(Exception e){
         return false;   
        }
    }
    public boolean Sonletras(String cadena){
        for (int i=0; i<cadena.length(); i++){
            char caracter = cadena.charAt(i);
            if (caracter>47 && caracter<58){
                return false;
            }
        }
        return true;
    }
    public boolean Rangovalido(int numero, int minimo, int maximo){
        if(numero > minimo && numero < maximo){
            return true;
        }else{
            return false;
        }
    }
}
