/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validaciones;

/**
 *
 * @author quiroz
 */
public class Usuariosycontrasenas {
    public boolean Parametrovalido(String cadena, int longitud_minima,
            int longitud_maxima, int mayusculas, int minusculas, int numeros){
        if(cadena.length()>=longitud_minima && cadena.length()<=longitud_maxima){
         int may=0, min=0, num=0;
            for (int i = 0; i<cadena.length(); i++){
             char caracter = cadena.charAt(i);
             if(caracter>64 && caracter<91)
                 may++;
             if(caracter>96 && caracter<123)
                 min++;
             if(caracter>47 && caracter<58)
                 num++;
         }
            if(may>=mayusculas && min>=minusculas && num>=numeros){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
}
