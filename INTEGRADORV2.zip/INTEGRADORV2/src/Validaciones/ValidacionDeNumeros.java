/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validaciones;

import java.awt.Color;
import javax.swing.JOptionPane;

/**
 *
 * @author quiroz
 */
public class ValidacionDeNumeros {

    public void validacion(String numero, String campo) {
        Numerosyletras numeros = new Numerosyletras();
        if (numeros.Esnumero(numero) == false) {
            JOptionPane.showMessageDialog(null, "El dato " + numero + " no es valido para el campo " + campo);
        }
    }

}
